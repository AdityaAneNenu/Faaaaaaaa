package com.snu.campusdirectory.dto;

import com.snu.campusdirectory.entity.ServiceRequest;
import jakarta.validation.constraints.NotNull;

public record StatusUpdateInput(@NotNull(message = "Status is required") ServiceRequest.Status status) {}
