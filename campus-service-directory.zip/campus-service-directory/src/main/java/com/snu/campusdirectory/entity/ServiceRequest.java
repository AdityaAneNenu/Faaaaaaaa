package com.snu.campusdirectory.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "service_requests")
public class ServiceRequest {
    public enum Status { PENDING, IN_PROGRESS, RESOLVED }
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "requester_name", nullable = false, length = 100)
    private String requesterName;
    @Column(name = "service_category", nullable = false, length = 60)
    private String serviceCategory;
    @Column(nullable = false, length = 150)
    private String location;
    @Column(name = "problem_description", nullable = false, length = 1000)
    private String problemDescription;
    @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20)
    private Status status = Status.PENDING;
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public ServiceRequest() {}
    public ServiceRequest(String requesterName, String serviceCategory, String location, String problemDescription) {
        this.requesterName = requesterName; this.serviceCategory = serviceCategory; this.location = location; this.problemDescription = problemDescription;
        this.status = Status.PENDING; this.createdAt = LocalDateTime.now();
    }
    public Long getId() { return id; }
    public String getRequesterName() { return requesterName; }
    public String getServiceCategory() { return serviceCategory; }
    public String getLocation() { return location; }
    public String getProblemDescription() { return problemDescription; }
    public Status getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setId(Long id) { this.id = id; }
    public void setRequesterName(String requesterName) { this.requesterName = requesterName; }
    public void setServiceCategory(String serviceCategory) { this.serviceCategory = serviceCategory; }
    public void setLocation(String location) { this.location = location; }
    public void setProblemDescription(String problemDescription) { this.problemDescription = problemDescription; }
    public void setStatus(Status status) { this.status = status; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
