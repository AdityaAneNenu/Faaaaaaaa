package com.snu.campusdirectory.repository;

import com.snu.campusdirectory.entity.CampusService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface CampusServiceRepository extends JpaRepository<CampusService, Long> {
    @Query("SELECT s FROM CampusService s WHERE " +
           "(:q IS NULL OR LOWER(s.name) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
           "LOWER(s.category) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
           "LOWER(COALESCE(s.location, '')) LIKE LOWER(CONCAT('%', :q, '%')) OR " +
           "LOWER(COALESCE(s.description, '')) LIKE LOWER(CONCAT('%', :q, '%'))) AND " +
           "(:category IS NULL OR LOWER(s.category) = LOWER(:category))")
    List<CampusService> search(@Param("q") String q, @Param("category") String category);
}
