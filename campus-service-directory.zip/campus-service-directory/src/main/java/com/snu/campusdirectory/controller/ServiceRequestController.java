package com.snu.campusdirectory.controller;

import com.snu.campusdirectory.dto.ServiceRequestInput;
import com.snu.campusdirectory.dto.StatusUpdateInput;
import com.snu.campusdirectory.entity.ServiceRequest;
import com.snu.campusdirectory.service.ServiceRequestManager;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/requests")
public class ServiceRequestController {
    private final ServiceRequestManager manager;
    public ServiceRequestController(ServiceRequestManager manager) { this.manager = manager; }
    @PostMapping @ResponseStatus(HttpStatus.CREATED) public ServiceRequest create(@Valid @RequestBody ServiceRequestInput input) { return manager.create(input); }
    @GetMapping public List<ServiceRequest> getAll() { return manager.findAll(); }
    @GetMapping("/{id}") public ServiceRequest getById(@PathVariable Long id) { return manager.findById(id); }
    @PatchMapping("/{id}/status") public ServiceRequest updateStatus(@PathVariable Long id, @Valid @RequestBody StatusUpdateInput input) { return manager.updateStatus(id, input.status()); }
}
