-- Run this script in MySQL Workbench or the MySQL command-line client.
CREATE DATABASE IF NOT EXISTS campus_service_directory
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_service_directory;

-- Spring Boot + Hibernate creates/updates these tables from the Java entities.
-- This script intentionally only creates/selects the database to avoid having
-- two competing definitions of the schema.
