package com.snu.campusdirectory.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ServiceRequestInput(
    @NotBlank(message = "Requester name is required") @Size(max = 100) String requesterName,
    @NotBlank(message = "Service category is required") @Size(max = 60) String serviceCategory,
    @NotBlank(message = "Location is required") @Size(max = 150) String location,
    @NotBlank(message = "Problem description is required") @Size(max = 1000) String problemDescription
) {}
