const API = '/api';
const $ = (selector) => document.querySelector(selector);
const serviceGrid = $('#services-grid');
const requestsBody = $('#requests-body');
let allServices = [];
let searchTimer;

const serviceIcons = {
  'Computer Repair': '⌘', 'Electrical Maintenance': 'ϟ', 'Transport': '↗',
  'Hostel Maintenance': '⌂', 'Stationery Shop': '✎', 'Other': '＋'
};
const statusLabels = { PENDING: 'Pending', IN_PROGRESS: 'In Progress', RESOLVED: 'Resolved' };
const statusClass = { PENDING: 'status-pending', IN_PROGRESS: 'status-in-progress', RESOLVED: 'status-resolved' };

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      message = body.details ? body.details.join('. ') : (body.message || body.error || message);
    } catch (_) { /* The server did not return JSON. */ }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function renderServices(services) {
  $('#result-count').textContent = `${services.length} service${services.length === 1 ? '' : 's'} found`;
  if (!services.length) {
    serviceGrid.innerHTML = '<div class="empty-state">No matching services. Try another search or category.</div>';
    return;
  }
  serviceGrid.innerHTML = services.map(service => `
    <article class="service-card">
      <div class="service-top"><span class="service-icon">${serviceIcons[service.category] || '＋'}</span><span class="availability">${escapeHtml(service.availability)}</span></div>
      <h3>${escapeHtml(service.name)}</h3><span class="service-category">${escapeHtml(service.category)}</span>
      <p class="service-description">${escapeHtml(service.description || 'Campus service support.')}</p>
      <div class="service-details">
        <div class="detail-row"><span>♙</span><div><b>${escapeHtml(service.responsiblePerson)}</b><small>Responsible person</small></div></div>
        <div class="detail-row"><span>☎</span><div><b>${escapeHtml(service.contactDetails)}</b><small>Contact details</small></div></div>
        <div class="detail-row"><span>⌖</span><div><b>${escapeHtml(service.location || 'Campus')}</b><small>Location</small></div></div>
        <div class="detail-row"><span>◷</span><div><b>${escapeHtml(service.workingHours)}</b><small>Working hours</small></div></div>
      </div>
      <button class="card-request" type="button" data-category="${escapeHtml(service.category)}">Raise a request →</button>
    </article>`).join('');
  serviceGrid.querySelectorAll('.card-request').forEach(button => button.addEventListener('click', () => {
    $('#request-category').value = button.dataset.category;
    $('#new-request').scrollIntoView({ behavior: 'smooth' });
    $('#requester-name').focus({ preventScroll: true });
  }));
}

async function loadServices() {
  try {
    const query = $('#search-input').value.trim();
    const category = $('#category-filter').value;
    const params = new URLSearchParams();
    if (query) params.set('q', query);
    if (category) params.set('category', category);
    const services = await api(`${API}/services?${params.toString()}`);
    allServices = services;
    renderServices(services);
    $('#service-count').textContent = services.length;
  } catch (error) {
    serviceGrid.innerHTML = `<div class="empty-state">Could not load services. Check that the Spring Boot server and MySQL are running.<br>${escapeHtml(error.message)}</div>`;
    $('#result-count').textContent = 'Unable to load';
  }
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : date.toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

async function loadRequests() {
  try {
    const requests = await api(`${API}/requests`);
    $('#pending-count').textContent = requests.filter(item => item.status === 'PENDING').length;
    $('#resolved-count').textContent = requests.filter(item => item.status === 'RESOLVED').length;
    if (!requests.length) {
      requestsBody.innerHTML = '<tr><td colspan="6" class="empty-state">No requests yet. Submit your first service request above.</td></tr>';
      return;
    }
    requestsBody.innerHTML = requests.map(item => `<tr>
      <td>#${item.id}</td><td>${escapeHtml(item.requesterName)}</td><td>${escapeHtml(item.serviceCategory)}</td>
      <td>${escapeHtml(item.location)}</td><td>${escapeHtml(formatDate(item.createdAt))}</td>
      <td><span class="status-pill ${statusClass[item.status] || ''}">${escapeHtml(statusLabels[item.status] || item.status)}</span></td>
    </tr>`).join('');
  } catch (error) {
    requestsBody.innerHTML = `<tr><td colspan="6" class="empty-state">Could not load requests. ${escapeHtml(error.message)}</td></tr>`;
  }
}

function showToast(message) {
  const toast = $('#toast'); toast.textContent = message; toast.classList.add('show');
  window.setTimeout(() => toast.classList.remove('show'), 3200);
}

$('#search-input').addEventListener('input', () => {
  window.clearTimeout(searchTimer);
  searchTimer = window.setTimeout(loadServices, 250);
});
$('#category-filter').addEventListener('change', loadServices);
$('#refresh-requests').addEventListener('click', loadRequests);

$('#request-form').addEventListener('submit', async event => {
  event.preventDefault();
  const message = $('#form-message');
  const button = event.currentTarget.querySelector('button[type="submit"]');
  message.textContent = 'Submitting your request…'; message.className = 'form-message'; button.disabled = true;
  const formData = new FormData(event.currentTarget);
  const payload = Object.fromEntries(formData.entries());
  try {
    const created = await api(`${API}/requests`, { method: 'POST', body: JSON.stringify(payload) });
    message.textContent = `Request #${created.id} submitted successfully. Status: Pending.`;
    message.className = 'form-message success';
    event.currentTarget.reset();
    await loadRequests();
    showToast(`Request #${created.id} created successfully`);
    $('#requests').scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (error) {
    message.textContent = `Could not submit request: ${error.message}`;
    message.className = 'form-message error';
  } finally { button.disabled = false; }
});

loadServices();
loadRequests();
