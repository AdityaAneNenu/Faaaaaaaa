package com.snu.campusdirectory.service;

import com.snu.campusdirectory.entity.CampusService;
import com.snu.campusdirectory.repository.CampusServiceRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {
    @Bean CommandLineRunner seedServices(CampusServiceRepository repository) {
        return args -> {
            if (repository.count() == 0) {
                repository.save(new CampusService("Computer Repair Desk", "Computer Repair", "IT Block, Ground Floor", "Arun Kumar", "+91 98765 10001", "Available on working days", "9:00 AM - 5:00 PM", "Laptop, desktop, printer and network troubleshooting."));
                repository.save(new CampusService("Electrical Maintenance", "Electrical Maintenance", "Facilities Office, Block A", "Priya Raman", "+91 98765 10002", "Emergency support available", "8:00 AM - 6:00 PM", "Electrical faults, lights, fans and power outlets."));
                repository.save(new CampusService("Campus Transport Office", "Transport", "Admin Block, Room 104", "Suresh Babu", "+91 98765 10003", "Available on working days", "8:30 AM - 5:30 PM", "Bus routes, transport schedules and transport queries."));
                repository.save(new CampusService("Hostel Maintenance", "Hostel Maintenance", "Hostel Office, Reception", "Meena Devi", "+91 98765 10004", "Daily; urgent issues prioritised", "9:00 AM - 7:00 PM", "Plumbing, room fixtures, housekeeping and hostel repairs."));
                repository.save(new CampusService("Campus Stationery Shop", "Stationery Shop", "Student Centre, Shop 3", "Karthik Raj", "+91 98765 10005", "Open daily", "9:00 AM - 8:00 PM", "Notebooks, pens, printing, photocopying and supplies."));
            }
        };
    }
}
