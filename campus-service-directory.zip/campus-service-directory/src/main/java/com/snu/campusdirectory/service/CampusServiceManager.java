package com.snu.campusdirectory.service;

import com.snu.campusdirectory.entity.CampusService;
import com.snu.campusdirectory.repository.CampusServiceRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CampusServiceManager {
    private final CampusServiceRepository repository;
    public CampusServiceManager(CampusServiceRepository repository) { this.repository = repository; }
    public List<CampusService> search(String q, String category) {
        String cleanQ = q == null || q.isBlank() ? null : q.trim();
        String cleanCategory = category == null || category.isBlank() || category.equalsIgnoreCase("All categories") ? null : category.trim();
        return repository.search(cleanQ, cleanCategory);
    }
}
