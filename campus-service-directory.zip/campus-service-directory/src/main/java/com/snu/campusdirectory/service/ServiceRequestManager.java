package com.snu.campusdirectory.service;

import com.snu.campusdirectory.dto.ServiceRequestInput;
import com.snu.campusdirectory.entity.ServiceRequest;
import com.snu.campusdirectory.repository.ServiceRequestRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
public class ServiceRequestManager {
    private final ServiceRequestRepository repository;
    public ServiceRequestManager(ServiceRequestRepository repository) { this.repository = repository; }
    public ServiceRequest create(ServiceRequestInput input) {
        ServiceRequest request = new ServiceRequest(input.requesterName().trim(), input.serviceCategory().trim(), input.location().trim(), input.problemDescription().trim());
        return repository.save(request);
    }
    public List<ServiceRequest> findAll() { return repository.findAllByOrderByCreatedAtDesc(); }
    public ServiceRequest findById(Long id) { return repository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Request " + id + " was not found")); }
    public ServiceRequest updateStatus(Long id, ServiceRequest.Status status) {
        ServiceRequest request = findById(id);
        request.setStatus(status);
        return repository.save(request);
    }
}
