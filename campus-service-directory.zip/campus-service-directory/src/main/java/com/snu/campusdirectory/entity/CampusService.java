package com.snu.campusdirectory.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "campus_services")
public class CampusService {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 100)
    private String name;
    @Column(nullable = false, length = 60)
    private String category;
    @Column(length = 100)
    private String location;
    @Column(name = "responsible_person", nullable = false, length = 100)
    private String responsiblePerson;
    @Column(name = "contact_details", nullable = false, length = 100)
    private String contactDetails;
    @Column(nullable = false, length = 100)
    private String availability;
    @Column(name = "working_hours", nullable = false, length = 100)
    private String workingHours;
    @Column(length = 500)
    private String description;

    public CampusService() {}
    public CampusService(String name, String category, String location, String responsiblePerson, String contactDetails, String availability, String workingHours, String description) {
        this.name = name; this.category = category; this.location = location; this.responsiblePerson = responsiblePerson;
        this.contactDetails = contactDetails; this.availability = availability; this.workingHours = workingHours; this.description = description;
    }
    public Long getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public String getLocation() { return location; }
    public String getResponsiblePerson() { return responsiblePerson; }
    public String getContactDetails() { return contactDetails; }
    public String getAvailability() { return availability; }
    public String getWorkingHours() { return workingHours; }
    public String getDescription() { return description; }
    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setCategory(String category) { this.category = category; }
    public void setLocation(String location) { this.location = location; }
    public void setResponsiblePerson(String responsiblePerson) { this.responsiblePerson = responsiblePerson; }
    public void setContactDetails(String contactDetails) { this.contactDetails = contactDetails; }
    public void setAvailability(String availability) { this.availability = availability; }
    public void setWorkingHours(String workingHours) { this.workingHours = workingHours; }
    public void setDescription(String description) { this.description = description; }
}
