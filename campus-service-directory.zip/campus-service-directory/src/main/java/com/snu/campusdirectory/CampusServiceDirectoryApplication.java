package com.snu.campusdirectory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusServiceDirectoryApplication {
    public static void main(String[] args) {
        SpringApplication.run(CampusServiceDirectoryApplication.class, args);
    }
}
