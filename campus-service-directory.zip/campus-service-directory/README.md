# CampusConnect — Campus Service Directory

A beginner-friendly full-stack lab project for **25CS5801 — Full Stack Web Development Lab**. It uses Java 17, Spring Boot, Spring Data JPA, MySQL, HTML, CSS and vanilla JavaScript.

## Assignment requirements covered

1. Search campus services: computer repair, electrical maintenance, transport, hostel maintenance and stationery shops.
2. Read the responsible person's name, contact details, availability and working hours from MySQL.
3. Submit requests with requester name, service category, location and problem description.
4. Save requests in MySQL, assign a unique auto-increment request ID and start each request as `PENDING`.
5. Provide REST APIs to search services, create/read requests and update request status to `PENDING`, `IN_PROGRESS` or `RESOLVED`.

> The people, phone numbers and campus locations preloaded by `DataInitializer.java` are demonstration data. Replace them with verified details before presenting this as real campus information.

## Requirements before running

- JDK 17 or newer
- MySQL Server 8.x (or a compatible MySQL version)
- Maven 3.8+ (or use the Maven wrapper if you add one through your IDE)

Check installations:

```bash
java -version
mvn -version
mysql --version
```

## Setup and run

### 1. Create the database

Open MySQL Workbench, connect to your local MySQL server, and run `database/create_database.sql`. Or execute:

```sql
CREATE DATABASE campus_service_directory;
```

### 2. Configure database credentials

Open `src/main/resources/application.properties`. By default, the application uses:

- URL: `jdbc:mysql://localhost:3306/campus_service_directory...`
- Username: `root`
- Password: blank

Change `spring.datasource.username` and `spring.datasource.password` to match your local MySQL account. Alternatively, set environment variables:

**Windows PowerShell**

```powershell
$env:DB_USERNAME = "root"
$env:DB_PASSWORD = "your_mysql_password"
$env:DB_URL = "jdbc:mysql://localhost:3306/campus_service_directory?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata"
```

**macOS/Linux**

```bash
export DB_USERNAME=root
export DB_PASSWORD='your_mysql_password'
export DB_URL='jdbc:mysql://localhost:3306/campus_service_directory?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata'
```

### 3. Start the application

From the project root directory:

```bash
mvn spring-boot:run
```

Wait until the console says that Spring Boot has started. On the first run, Hibernate creates the tables and `DataInitializer.java` inserts five demo services if the service table is empty.

### 4. Open the website

Visit **http://localhost:8080** in your browser. The frontend is served by Spring Boot; you do not need Live Server or a separate Node.js process.

### 5. Test the REST API

Use Postman, or run the following in a terminal:

```bash
# Search all services
curl http://localhost:8080/api/services

# Search for a keyword
curl "http://localhost:8080/api/services?q=hostel"

# Filter by category
curl "http://localhost:8080/api/services?category=Transport"

# Create a request (PowerShell users can paste this as one line)
curl -X POST http://localhost:8080/api/requests -H "Content-Type: application/json" -d "{\"requesterName\":\"Adi\",\"serviceCategory\":\"Hostel Maintenance\",\"location\":\"Hostel Block B, Room 204\",\"problemDescription\":\"The room light is not working.\"}"

# List requests
curl http://localhost:8080/api/requests

# Get request with ID 1
curl http://localhost:8080/api/requests/1

# Update request 1 to in progress
curl -X PATCH http://localhost:8080/api/requests/1/status -H "Content-Type: application/json" -d "{\"status\":\"IN_PROGRESS\"}"

# Resolve request 1
curl -X PATCH http://localhost:8080/api/requests/1/status -H "Content-Type: application/json" -d "{\"status\":\"RESOLVED\"}"
```

## REST API reference

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/api/services` | List/search services; optional `q` and `category` query parameters |
| `GET` | `/api/services/{id}` | Get one service by ID |
| `POST` | `/api/requests` | Submit a new service request; returns HTTP 201 |
| `GET` | `/api/requests` | List requests, newest first |
| `GET` | `/api/requests/{id}` | Get one request by ID |
| `PATCH` | `/api/requests/{id}/status` | Update status |

Valid status values in JSON are uppercase enum values: `PENDING`, `IN_PROGRESS`, `RESOLVED`. The UI displays them as Pending, In Progress and Resolved.

Example create-request JSON:

```json
{
  "requesterName": "Adi",
  "serviceCategory": "Computer Repair",
  "location": "IT Block, Room 102",
  "problemDescription": "The lab computer will not start."
}
```

Example status update JSON:

```json
{ "status": "IN_PROGRESS" }
```

## File-by-file guide

### Root files

- `pom.xml` — Maven project file. Defines Java version and dependencies: Spring Web for REST, Spring Data JPA for database access, Validation for checking inputs, and the MySQL JDBC driver.
- `README.md` — setup, API examples and explanations.
- `.gitignore` — prevents build output and local IDE files from being committed.
- `database/create_database.sql` — creates the database. Hibernate generates the tables from the entity classes.

### Java files

- `CampusServiceDirectoryApplication.java` — application entry point. `@SpringBootApplication` starts component scanning and Spring Boot configuration.
- `entity/CampusService.java` — JPA entity mapped to `campus_services`. Stores service name/category, location, responsible person, contact details, availability, hours and description.
- `entity/ServiceRequest.java` — JPA entity mapped to `service_requests`. Its generated `id` is the unique request ID; new requests start at `PENDING`. It records creation time and status.
- `dto/ServiceRequestInput.java` — request payload object. Validation annotations reject missing or excessively long form fields.
- `dto/StatusUpdateInput.java` — validates the status supplied when updating a request.
- `repository/CampusServiceRepository.java` — Spring Data JPA database access for searching services by keyword and category. You do not write basic SQL manually because Spring Data builds the query.
- `repository/ServiceRequestRepository.java` — database access for saving and retrieving requests, sorted newest first.
- `service/CampusServiceManager.java` — service-search logic; normalizes empty search fields before querying.
- `service/ServiceRequestManager.java` — creates requests, lists and fetches them, and changes status. Keeping business logic here helps controllers remain small.
- `service/DataInitializer.java` — inserts five demo services only when the service table is empty.
- `controller/CampusServiceController.java` — handles `GET /api/services` and `GET /api/services/{id}`.
- `controller/ServiceRequestController.java` — handles creating, listing, reading and status-updating service requests.
- `exception/ApiExceptionHandler.java` — returns readable HTTP 400 errors for invalid input and malformed status JSON.
- `src/main/resources/application.properties` — port, database URL/credentials, JPA settings and JSON date formatting.

### Frontend files

- `static/index.html` — page structure, navigation, service search, request form and request table.
- `static/styles.css` — layout, colors, cards, responsive mobile styles and status badges.
- `static/app.js` — calls the REST API with `fetch()`, renders service cards and request rows, validates form submission through HTML plus backend validation, and displays success/error messages. `escapeHtml()` protects text returned from the database from being interpreted as HTML.

## Beginner explanation: request lifecycle

1. The student fills out the form in `index.html`.
2. `app.js` collects the fields and sends a JSON `POST` request to `/api/requests`.
3. `ServiceRequestController` receives the JSON and validates it using `@Valid`.
4. `ServiceRequestManager` creates a `ServiceRequest` entity and asks the repository to save it.
5. Hibernate sends the insert to MySQL. MySQL generates the numeric primary key.
6. Spring Boot returns the saved request as JSON; the frontend displays its ID and refreshes the request table.
7. A staff client can use the PATCH endpoint to change the status. The website then displays the updated status when refreshed.

## Troubleshooting

- **`Access denied for user`** — check the MySQL username and password in `application.properties` or environment variables.
- **`Communications link failure`** — make sure the MySQL service is running and port 3306 is available.
- **Unknown database** — run `database/create_database.sql` first, or verify the configured database name.
- **Port 8080 already in use** — stop the other application using that port or change `server.port` in `application.properties`.
- **Maven cannot find Java** — install JDK 17+ and configure `JAVA_HOME`/PATH.
- **No services appear** — inspect the terminal for database errors, then refresh the page. The demo services are inserted on application startup if `campus_services` has no rows.

## Scope and production notes

This is an educational lab project. It does not include login, role-based access control, email notifications or audit logs. The status update endpoint is intentionally simple for demonstration; a real deployment should restrict it to authorized staff and use a secure database password. For real campus use, replace all demonstration contact details with verified information.
