package com.snu.campusdirectory.controller;

import com.snu.campusdirectory.entity.CampusService;
import com.snu.campusdirectory.service.CampusServiceManager;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/services")
public class CampusServiceController {
    private final CampusServiceManager manager;
    public CampusServiceController(CampusServiceManager manager) { this.manager = manager; }
    @GetMapping public List<CampusService> search(@RequestParam(required = false) String q, @RequestParam(required = false) String category) { return manager.search(q, category); }
    @GetMapping("/{id}") public CampusService getById(@PathVariable Long id) {
        return manager.search(null, null).stream().filter(s -> s.getId().equals(id)).findFirst().orElseThrow(() -> new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.NOT_FOUND, "Service not found"));
    }
}
